import Vue from 'vue'
import App from './App.vue'
import router from './router'
import 'lib-flexible/flexible'
Vue.config.productionTip = false

import { Checkbox, CheckboxGroup, Uploader, Notify, Dialog } from 'vant';

Vue.use(Checkbox);
Vue.use(CheckboxGroup);
Vue.use(Uploader);
Vue.prototype.$Dialog = Dialog
Vue.prototype.$Notify = Notify

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
