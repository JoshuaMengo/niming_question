<template>
  <div class="detail">
    <div class="header">
      <div class="top">
        <div>返回</div>
        <div>...</div>
      </div>
      <div class="bottom">
        <div class="tit">匿名提问</div>
        <div class="content">
          提问内容提问内容提问内容提问内容提问内容提问内容提问内容问内容提提问内容问内容
        </div>
      </div>
    </div>
    <div class="container">
      <div>
        <textarea placeholder="输入回答内容..." />
      </div>

      <div>确定</div>
    </div>

    <div class="shareContainer">
      <div>我也要玩</div>
      <div>Ta的提问箱</div>
    </div>
  </div>
</template>

<script>
export default {
  name: "detail",
  data() {
    return {};
  },
};
</script>
<style lang="less" scoped>
.detail {
  & > div {
    padding: 20px;
  }
  .header {
    background: #f8dd9d;
    & > .top {
      display: flex;
      justify-content: space-between;
      & > div:nth-child(1) {
        width: 55px;
        height: 30px;
        line-height: 30px;
        border-radius: 20px;
        background-color: rgba(16, 16, 16, 100);
        color: rgba(247, 247, 247, 100);
        font-size: 13px;
        text-align: center;
      }
      & > div:nth-child(2) {
      }
    }
    & > .bottom {
      width: 275px;
      height: 128px;
      border-radius: 6px;
      background-color: rgba(255, 255, 255, 100);
      margin-top: 20px;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 15px 30px;
      & > .tit {
        color: rgba(16, 16, 16, 0.5);
        font-size: 14px;
        margin-bottom: 30px;
      }
      & > .content {
        flex: 1;
        color: rgba(61, 61, 61, 1);
        font-size: 15px;
      }
    }
  }
  & > .container {
    & > div:nth-child(1) {
      background-color: rgba(250, 250, 251, 100);
      border-radius: 8px;
      padding: 20px;
      margin-bottom: 10px;
      textarea {
        width: 100%;
        height: 150px;
        line-height: 20px;
        border: 0;
        background-color: rgba(250, 250, 251, 100);
      }
    }
    & > :nth-child(2) {
      width: 335px;
      height: 44px;
      line-height: 40px;
      border-radius: 5px;
      background-color: rgba(16, 16, 16, 100);
      color: rgba(255, 255, 255, 100);
      font-size: 14px;
      text-align: center;
    }
  }
  & > .shareContainer {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    display: flex;
    justify-content: space-between;
    & > div {
      width: 160px;
      height: 50px;
      line-height: 50px;
      font-size: 15px;
      text-align: center;
      border-radius: 25px;
    }
    & > div:nth-child(1) {
      background-color: rgba(249, 213, 126, 100);
      color: rgba(16, 16, 16, 100);
    }
    & > div:nth-child(2) {
      background-color: rgba(16, 16, 16, 100);
      color: rgba(255, 255, 255, 100);
    }
  }
}
</style>