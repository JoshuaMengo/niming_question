<template>
  <div class="poster">
    <div class="container">
      <div class="header">
        <img src="@/assets/v2_qkaufe.png" />
        <div>“问题内容问题内容问题内容问题内容问题内容”</div>
      </div>
      <div class="content">
        <div>NickName 的回答：</div>
        <div>
          回答内容回答内容回答内容回答内容回答内容回答内容回答内容回答内容......
        </div>
        <div>
          <div>长按识别二维码<br/>查看问题详情→</div>
          <div></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "poster",
  data() {},
};
</script>

<style lang="less" scoped>
.poster {
  position: fixed;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  background: #f7f7f7;
  padding: 20px 25px;
  .container {
    border-radius: 8px;
    overflow: hidden;
    .header {
      background-color: rgba(249, 213, 126, 100);
      padding: 25px 20px;
      img {
        width: 88px;
        height: 35px;
      }
      & > div {
        margin-top: 30px;
        color: rgba(16, 16, 16, 100);
        font-size: 15px;
      }
    }
    .content {
      background: white;
      padding: 20px;
      & > div:nth-child(1) {
        margin-bottom: 20px;
      }
      & > div:nth-child(2) {
        border-radius: 6px;
        background-color: rgba(250, 250, 251, 100);
        padding: 20px;
        height: 40px;
        line-height: 20px;
        overflow: hidden;
        color: rgba(16, 16, 16, 100);
        font-size: 14px;
        margin-bottom: 35px;
      }
      & > div:nth-child(3) {
        display: flex;
        justify-content: space-between;
        align-items: center;
        &>div:nth-child(1){
            color: rgba(16, 16, 16, 100);
font-size: 13px;
        }
        & > div:nth-child(2) {
          width: 65px;
          height: 65px;
          border-radius: 50%;
          text-align: center;
          border: 1px solid rgba(187, 187, 187, 100);
        }
      }
    }
  }
}
</style>