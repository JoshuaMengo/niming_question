<template>
  <div class="home">
    <!-- 头部分享，tabbar -->
    <div class="header">
      <div class="top">
        <div><img src="@/assets/v2_qkaufe.png" /></div>
        <div>
          <div></div>
          <div>我的></div>
        </div>
      </div>
      <div class="tabbar">
        <div
          v-for="(item, index) in tabbarList"
          :key="index"
          :class="activeTabbarIndex === index ? 'activeTabbar' : ''"
          @click="changeIndex(index)"
        >
          {{ item.name }}
        </div>
      </div>
    </div>

    <div class="container" v-if="list.length>0">
      <div class="item" v-for="(item, index) in list" :key="index">
        <div class="title">匿名提问</div>
        <div class="content">“你怎么看待特朗普宣布自己大选获胜”</div>
        <div class="status">未回答</div>
      </div>
    </div>

    <div v-else class="nothing">
      <img src="@/assets/v2_qkcfa2.png"/>
    </div>
    <!-- <div></div> -->


    <!-- 底部分享按钮 -->
    <div :class="closeShare ?'footerBtn closeShare' :'footerBtn'">
      <img @click="closeShare = !closeShare" src="@/assets/v2_qkceif.png" />
      <div v-show="!closeShare"  class="text"><p>邀请好友提问</p></div>
      <div v-show="!closeShare"  @click="closeShare = !closeShare" class="right"><img src="@/assets/v2_qkchd3.png" /></div>
    </div>


    <!-- 分享提示弹唱 -->
    <div class="shareTips_Dialog">

    </div>


    <!-- 入场加载动画 -->
    <div class="loading" v-show="loading">
      <div>
        <img src="@/assets/v2_qkyqr7.gif" />
      </div>
      <div>
        <img src="@/assets/v2_qkaufe.png" />
      </div>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: "Home",
  data() {
    return {
      loading: false,
      tabbarList: [
        { name: "收到的提问" },
        { name: "我的回答" },
        { name: "我的提问" },
        { name: "收到的回答" },
      ],
      activeTabbarIndex: 0,
      list:[],
      closeShare:false
    };
  },

  methods: {
    changeIndex(index) {
      this.activeTabbarIndex = index;
    },
  },
};
</script>

<style lang="less" scoped>
.home {
 
  .header {
    background: white;
    .top {
      display: flex;
      justify-content: space-between;
      padding: 25px 20px 30px;
      align-items: center;
      & > div:nth-child(1) {
        img {
          width: 98px;
          height: 35px;
        }
      }
    }
    .tabbar {
      display: flex;
      justify-content: space-around;
      & > div {
        width: 70px;
        padding: 5px 0;
        text-align: center;
      }
      & > .activeTabbar {
        border-bottom: 1px solid #f9d57e;
        font-weight: bold;
      }
    }
  }
  .nothing{
     height: 115px;
      width: 115px;
      margin: 96px auto 0;
    img{
     height:100%;
     width:100%;
    }
  }

  .container {
    padding: 25px 15px;
    & > .item {
      border-radius: 3px;
      background: white;
      padding: 15px 20px;
      margin-bottom: 15px;
      & > .title {
        color: rgba(16, 16, 16, 0.35);
        font-size: 14px;
      }
      & > .content {
        color: rgba(16, 16, 16, 100);
        font-size: 15px;
        padding: 10px 0 9px;
        border-bottom: 1px solid rgba(244, 245, 245, 100);
      }
      & > .status {
        color: rgba(16, 16, 16, 0.35);
        font-size: 14px;
        margin-top: 9px;
      }
    }
  }

 &> .footerBtn {
   position:fixed;
    width:345px;
    bottom: 20px;
    right: 0;
    margin: 0 15px;
    height: 50px;
    text-align: center;
    border-radius: 30px;
    background-color: rgba(249, 213, 126, 100);
    display: flex;
    justify-content: center;
    align-items: center;
    font-weight: bold;
    transition: all .6s;
    & > img {
      height: 20px;
      width: 20px;
    }
    & >.text{
      margin-left:5px;
    height: 50px;
    line-height: 50px;
    overflow: hidden;
    }
    & > .right {
      position: absolute;
      right: 10px;
      top: 50%;
      height: 25px;
      width: 25px;
      opacity: 1;
      transform: translateY(-50%);
      & > img {
        height: 100%;
        width: 100%;
      }
    }
  }
  &>.closeShare{
    width:50px!important;
     
  }

  .loading {
    position: fixed;
    z-index: 999;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    display: flex;
    flex-direction: column;
    & > div:nth-child(1) {
      display: flex;
      align-items: center;
      justify-content: center;
      background: #f8d47d;
      flex: 1;
      & > img {
        height: 135px;
        width: 135px;
      }
    }
    & > div:nth-child(2) {
      height: 16.5%;
      display: flex;
      align-items: center;
      justify-content: center;
      & > img {
        height: 35px;
        width: 98px;
      }
    }
  }
}
</style>
