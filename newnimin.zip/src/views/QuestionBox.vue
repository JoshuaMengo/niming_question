<template>
  <div class="mine">
      <div class="header">
        <div>
            <div>＜首页</div>
        </div>

        <div class="userInfo">
            <div class="detail">
                <div></div>
                <div>
                    周星星
                </div>

            </div>
            <div class="num">
                收到提问 4  |  回答4
            </div>

        </div>
      </div>

      <div class="content">
            <div class="autograph">
                <div>签名：这是一条充话费送的签名。</div>
                <!-- <div><img src="@/assets/v2_qjxtra.png" /></div> -->
            </div>

            <div class="share_btn" v-if="isSelf">
                邀请好友提问
            </div>

            <div class="btn_container">
                <div>我也要玩</div>
                <div>向Ta提问</div>

            </div>
            
            <div class="questionDetail">    
                <div class="title">周星星回答的问题 4</div>
                <div v-if="list.length>0">
                    <div class="item" v-for="(item,index) in list" :key="index">
                        <div>匿名提问</div>
                        <div>“问题内容问题内容问题内容”</div>
                        <div><span>答</span>回答内容回答内容回答内容回答内容回答......</div>
                    </div>
                </div>
                <img v-else src="@/assets/v2_qkcfa2.png" />
            </div>
      </div>

  </div>
</template>

<script>
export default {
    data(){
        return{
            list:[{},{},{},{},{}]
        }
    }
}
</script>

<style lang="less" scoped>

.mine{

    .header{
        height:200px;
        // background:red;
        background:url('../assets/v2_qkbbax.jpg');
        background-size:contain;
        padding: 20px 20px 0;
        position:relative;
        &>div:nth-child(1){
            display: flex;
            font-size: 13px;
            justify-content: space-between;
            &>div:nth-child(1){
                width: 65px;
                height: 30px;
                line-height: 30px;
                border-radius: 20px;
                background-color: rgba(16, 16, 16, 100);
                color: rgba(247, 247, 247, 100);
                text-align: center;
            }
        }
        .userInfo{
            position:absolute;
            bottom:0;
            left:0;
            right:0;
            margin:0 20px;
            display:flex;
            justify-content: space-between;
            transform: translateY(20px);
            .detail{
                display: flex;
                &>div:nth-child(1){
                    width: 70px;
                    height: 70px;
                    border-radius: 10px;
                    background:#ccc;
                    margin-right: 15px;
                }
                &>div:nth-child(2){
                    color: rgba(16, 16, 16, 100);
                    font-size: 18px;
                    font-weight:bold;
                    margin-top:14px;
                }
            }
            .num{
                margin-top:15px;
                color: rgba(16, 16, 16, .5);
                font-size: 13px;
            }
        }
    }
    .content{
        .autograph{
            margin: 0 20px;
            
            margin-top: 30px;
            display: flex;
            justify-content: space-between;
            color: rgba(0, 0, 0, 0.5);
            font-size: 14px;
            img{
                height: 20px;
                width: 20px;
            }
        }
        .btn_container{
            padding: 25px 0 30px;
            display:flex;
            justify-content: center;
            &>div{
                font-size: 15px;
                width: 160px;
                height: 55px;
                text-align: center;
                line-height: 55px;
                border-radius: 100px;
                margin:0 15px;
            }
            &>div:nth-child(1){
                background-color: rgba(16, 16, 16, 100);
                color: rgba(255, 255, 255, 100);
            }
            &>div:nth-child(2){
                background-color: rgba(249, 213, 126, 100);
                color: rgba(16, 16, 16, 100);
            }
        }
        .share_btn{
            width: 335px;
            height: 80px;
            line-height: 80px;
            border-radius: 8px;
            background-color: rgba(249, 213, 126, 100);
            color: rgba(16, 16, 16, 100);
            font-size: 15px;
            text-align: center;
            margin: 25px auto 30px;
            font-weight: bold;
        }
        .questionDetail{
            background:#f7f7f7;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 25px 0 100px;
            img{
                height: 115px;
                width: 115px;
            }
            .title{
                margin-bottom: 20px;
                color: rgba(16, 16, 16, 100);
                font-size: 15px;
                font-weight: bold;
            }
            .item{
                background:white;
                width: 305px;
                // height: 152px;
                border-radius: 6px;
                padding: 15px 20px 20px;
                margin-bottom: 15px;
                &>div:nth-child(1){
                    color: rgba(16, 16, 16, .35);
                    font-size: 14px;
                    margin-bottom: 20px;
                }
                &>div:nth-child(2){
                    color: rgba(16, 16, 16, 100);
                    font-size: 15px;
                    padding-bottom:15px ;
                    border-bottom: 1px solid rgba(244, 245, 245, 100);
                    margin-bottom: 20px;
                }
                &>div:nth-child(3){
                    color: rgba(16, 16, 16, 100);
                    font-size: 14px;
                    &>span{
                        padding: 4px;
                        border-radius: 3px;
                        background-color: rgba(249, 213, 126, 100);
                        color: rgba(16, 16, 16, 100);
                        font-size: 12px;
                        text-align: center;
                        margin-right: 8px;
                    }
                }
            }
        }
        
        
    }
}

</style>