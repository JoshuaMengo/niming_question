<template>
  <div class="mine">
      <div class="header">
        <div>
            <div>＜首页</div>
            <div>更换背景</div>
        </div>

        <div class="userInfo">
            <div class="detail">
                <div></div>
                <div>
                    <div class="nickName">周星星</div>
                    <div class="id">UID 89445673</div>
                </div>

            </div>
            <div class="btn">更新信息</div>

        </div>
      </div>

      <div class="content">
          <div class="autograph">
              <div>签名：这是一条充话费送的签名。</div>
              <div><img src="@/assets/v2_qjxtra.png" /></div>
          </div>

          <div class="remind">
              <div><img src="@/assets/v2_qkax0u.png"/>开启消息提醒</div>
              <div><img src='@/assets/v2_qkceif.png' /></div>
          </div>

          <div class="panel">
              <div class="left">
                <div></div>
                <div></div>
              </div>
              <div class="right">
                <div></div>
                <div></div>
              </div>

          </div>
      </div>
    <div
      class="dialog"
      @click="showDialog = false"
    >
      <div class="content" @click.stop="">
        <div>谁看过我</div>
        <div class="operation_container">
          <div @click="pay({ fee: 200, body: once })">
            <div>偷看一次</div>
            <div>￥<span>2</span></div>
          </div>
          <div @click="pay({ fee: 1500, body: 'vip' })">
            <div>永久解锁</div>
            <div>￥<span>15</span><del>￥30</del></div>
          </div>
        </div>
        <div class="tips">
            Tips：包含所有访问/查看您提问箱的用户(可能包含非好友)及访问次数，不对应提问者和提问内容。
        </div>
        <div @click="$router.push('/feedback')">支付后无法进入？</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="less" scoped>

.mine{
    .dialog {
        background: rgba(0, 0, 0, 0.65);
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 0 35px;
        & > .content {
        background: white;
        border-radius: 10px;
        width: 100%;
        padding: 25px 32px;
        display: flex;
        flex-direction: column;
        align-items: center;
        & > div:nth-child(1) {
            color: rgba(16, 16, 16, 100);
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 30px;
        }
        & > div:last-child {
            color: rgba(76, 134, 234, 100);
            font-size: 12px;
            margin-top: 20px;
        }
        &>.tips{
            color: rgba(0, 0, 0, 0.35);
        }
        & > .operation_container {
            width: 100%;
            display: flex;
            justify-content: space-between;
            margin-bottom: 25px;
            color: rgba(16, 16, 16, 100);
            & > div {
            width: 115px;
            height: 115px;
            line-height: 32px;
            border-radius: 8px;
            background-color: #FFEDC2;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: space-around;
            span {
                font-weight: bold;
                font-size: 20px;
            }
            del {
                opacity: 0.6;
            }
            }

            & > div:nth-child(2) {
            background-color: #F9D57E;
            }
        }
        }
    }
    .header{
        height:200px;
        // background:red;
        background:url('../assets/v2_qkbbax.jpg');
        background-size:contain;
        padding: 20px 20px 0;
        position:relative;
        &>div:nth-child(1){
            display: flex;
            font-size: 13px;
            justify-content: space-between;
            &>div:nth-child(1){
                width: 65px;
                height: 30px;
                line-height: 30px;
                border-radius: 20px;
                background-color: rgba(16, 16, 16, 100);
                color: rgba(247, 247, 247, 100);
                text-align: center;
            }
            &>div:nth-child(2){
                width: 70px;
                height: 28px;
                line-height: 28px;
                border-radius: 20px;
                color: rgba(255, 255, 255, 100);
                text-align: center;
                border: 1px solid rgba(255, 255, 255, 100);
            }
        }
        .userInfo{
            position:absolute;
            bottom:0;
            left:0;
            right:0;
            margin:0 20px;
            display:flex;
            justify-content: space-between;
            transform: translateY(20px);
            .detail{
                display: flex;
                &>div:nth-child(1){
                    width: 70px;
                    height:70px;
                    border-radius: 5px;
                    background:#ccc;
                    margin-right: 15px;
                }
                .nickName{
                    color: rgba(16, 16, 16);
                    font-size: 18px;
                    margin: 3px 0;
                }
                .id{
                    color: rgba(16, 16, 16, .35);
                    font-size: 12px;
                }
            }
            .btn{
                width: 60px;
                height: 22px;
                line-height: 22px;
                border-radius: 3px;
                color: rgba(198, 191, 186, 100);
                font-size: 12px;
                background:white;
                text-align:center
            }
        }
    }
    &>.content{
        margin: 0 20px;
        .autograph{
            margin-top: 30px;
            display: flex;
            justify-content: space-between;
            color: rgba(0, 0, 0, 0.5);
            font-size: 14px;
            img{
                height: 20px;
                width: 20px;
            }
        }
        .remind{
            display:flex;
            height: 50px;
            margin-top:30px;
            &>div:nth-child(1){
                flex:1;
                border-radius: 16px;
                margin-right:10px;
                background-color: rgba(247, 247, 247, 100);
                display: flex;
                align-items: center;
                img{
                    width: 24px;
                    height: 24px;
                    margin: 0 8px 0 15px;
                }
            }
            &>div:nth-child(2){
                width: 50px;
                height: 50px;
                background:#FFEDC2;
                border-radius: 8px;
                display: flex;
                align-items: center;
                justify-content: center;
                 img{
                    width: 20px;
                    height: 20px;
                }
            }
        }
        .panel{
            margin-top:10px;
            display:flex;
            .left{
                width:135px;
                margin-right:10px;
                &>div{
                    background-color: rgba(247, 247, 247, 100);
                    border-radius: 8px;
                }
                &>div:nth-child(1){
                    height:135px;
                    width:100%;
                }
                 &>div:nth-child(2){
                    height:60px;
                    width:100%;
                    margin-top:10px;
                }
            }
            .right{
                flex:1;
                &>div{
                    background-color: rgba(247, 247, 247, 100);
                    border-radius: 8px;
                }
                &>div:nth-child(1){
                    height:115px;
                    width:100%;
                }
                 &>div:nth-child(2){
                    height:80px;
                    width:100%;
                    margin-top:10px;
                }
            }
        }
    }
}

</style>