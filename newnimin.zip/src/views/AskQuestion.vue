<template>
  <div class="askQuestion">
      <div class="header">
        <div>向NickName 提问</div>
        <div>取消</div>
      </div>

      <div class="content" v-if="islock">
        <textarea />
        <div class="commit">发送提问</div>
        <van-checkbox checked-color="#000000" style="font-size: 14px;" v-model="checked" >匿名提问 (取消勾选则实名提问)</van-checkbox>
        <div class="tips">尊重他人，礼貌提问<br/>恶意提问会被封禁账号哦</div>
      </div>

      <div class="islock" v-else>
          <img src="@/assets/v2_qkcgfh.png"/>
          <div>抱歉，对方拒绝接受您的提问</div>
      </div>

      
  </div>
</template>

<script>
export default {
    name:'askQuestion',
    data(){
        return{
            checked:false,
        }
    }
}
</script>

<style lang="less" scoped>
.askQuestion{
    padding: 20px;
    .header{
        display:flex;
        justify-content: space-between;
        align-items: center;
        &>div:nth-child(1){
            color: rgba(16, 16, 16, 100);
            font-size: 16px;
            font-weight: bold;
        }
        &>div:nth-child(2){
            width: 50px;
            height: 28px;
            line-height: 28px;
            border-radius: 20px;
            background-color: rgba(221, 221, 221, 100);
            color: rgba(255, 255, 255, 100);
            text-align: center;
        }
    }
    .content{
        textarea{
            width: 335px!important;
            height: 150px!important;
            border-radius: 8px;
            border: 1px solid rgba(16, 16, 16, .15)!important;
            margin: 20px 0 10px;
        }
        .commit{
            width: 335;
            height: 44px;
            line-height: 44px;
            border-radius: 5px;
            background-color: rgba(249, 213, 126, 100);
            color: rgba(16, 16, 16, 100);
            font-size: 14px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 20px;
        }
        .tips{
            margin:155px auto;
            text-align: center;
            line-height: 25px;
            color: rgba(16, 16, 16, .35);
            font-size: 13px;
        }
        
    }
    .islock{
        margin:0 auto;
        height: 175px;
        margin-top:55px;
        text-align: center;
        color: rgba(16, 16, 16, 100);
        font-size: 14px;
            img{
                height: 100%;
                width: 175px;
            }
        }
}
</style>